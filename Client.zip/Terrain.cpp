#include "stdafx.h"
#include "Terrain.h"

CTerrain::CTerrain()
{
}


CTerrain::~CTerrain()
{
	Release_GameObject(); 
}

HRESULT CTerrain::Create_Graph_Terrain()
{
	m_vecGraph.resize(TILEX * TILEY); 
	//m_vecGraph[2].emplace_back(TILE*); 

	return S_OK;
}

HRESULT CTerrain::LoadTileData_Terrain(const wstring & wstrFilePath)
{
	HANDLE hFile = CreateFile(wstrFilePath.c_str(), GENERIC_READ, 0, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr); 
	if (INVALID_HANDLE_VALUE == hFile)
		return E_FAIL; 

	DWORD dwbyte = 0; 
	MAPOBJECT* pMap = nullptr;
	//TILE* pTile = nullptr; 
	while (true)
	{
		//pTile = new TILE; 
		pMap = new MAPOBJECT;
		ReadFile(hFile, pMap, sizeof(MAPOBJECT), &dwbyte, nullptr);
		if (0 == dwbyte)
		{
			Safe_Delete(pMap);
			break; 
		}
		//m_vecTile.emplace_back(pTile); 
		m_vecMap.emplace_back(pMap);
	}
	CloseHandle(hFile); 
	return S_OK;
}

HRESULT CTerrain::Ready_GameObject()
{

	LoadTileData_Terrain(L"../Data/ObjectData1.dat"); 
	return S_OK;
}



int CTerrain::Update_GameObject()
{
	float fSpeed = 300.f * CTime_Manager::Get_Instance()->Get_DeltaTime(); 

	if (GetAsyncKeyState(VK_LEFT) & 0x8000)
		CScroll_Manager::Get_Instance()->Set_Scroll({ fSpeed, 0.f, 0.f });
	if (GetAsyncKeyState(VK_RIGHT) & 0x8000)
		CScroll_Manager::Get_Instance()->Set_Scroll({ -fSpeed, 0.f, 0.f });
	if (GetAsyncKeyState(VK_UP) & 0x8000)
		CScroll_Manager::Get_Instance()->Set_Scroll({ 0.f,fSpeed,  0.f });
	if (GetAsyncKeyState(VK_DOWN) & 0x8000)
		CScroll_Manager::Get_Instance()->Set_Scroll({ 0.f,-fSpeed,  0.f });

	// ���� �����ؿ�����. 3����. 
	// 
	return 0;
}

void CTerrain::Late_Update_GameObject()
{
}

void CTerrain::Render_GameObject()
{
	D3DXMATRIX matScale, matTrans, matWorld;
	DWORD dwSize = m_vecMap.size();
	
	for (size_t i = 0; i < dwSize; ++i)
	{
		//const TEXINFO* pTexInfo = CTexture_Manager::Get_Instance()->Get_TexInfo_Manager(L"Terrain", L"Tile", m_vecTile[i]->byDrawID);
		const TEXINFO* pTexInfo = CTexture_Manager::Get_Instance()->Get_TexInfo_Manager(L"MapObject", L"Gate", m_vecMap[i]->byDrawID);
		if (nullptr == pTexInfo)
			return;
		float fCenterX = float(pTexInfo->tImageInfo.Width >> 1);
		float fCenterY = float(pTexInfo->tImageInfo.Height >> 1);

		D3DXMatrixScaling(&matScale, m_vecMap[i]->vSize.x, m_vecMap[i]->vSize.y, 0.f);
		D3DXMatrixTranslation(&matTrans, m_vecMap[i]->vPos.x + CScroll_Manager::Get_Instance()->Get_Scroll(CScroll_Manager::eSB_HORZ), m_vecMap[i]->vPos.y + CScroll_Manager::Get_Instance()->Get_Scroll(CScroll_Manager::eSB_VERT), 0.f);
		matWorld = matScale * matTrans;

		CGraphic_Device::Get_Instance()->Get_Sprite()->SetTransform(&matWorld);
		CGraphic_Device::Get_Instance()->Get_Sprite()->Draw(pTexInfo->pTexture, nullptr, &D3DXVECTOR3(fCenterX, fCenterY, 0.f), nullptr, D3DCOLOR_ARGB(255, 255, 255, 255));
	}
}

void CTerrain::Release_GameObject()
{
	for (auto& pTile : m_vecMap)
		Safe_Delete(pTile);
	m_vecMap.clear();
	m_vecMap.shrink_to_fit();
}
