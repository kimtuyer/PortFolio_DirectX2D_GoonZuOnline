#pragma once
class CGameObject; 
class CGameObject_Manager
{
	DECLARE_SINGLETON(CGameObject_Manager)
public:
	enum ID {MAP,TERRAIN, PLAYER, MONSTER, BOSS, UI, END};
private:
	CGameObject_Manager();
	~CGameObject_Manager();
public:
	HRESULT Add_GameObject_Manager(ID eID, CGameObject* pObject); 
	void Update_GameObject_Manager(); 
	void Render_GameObject_Manager(); 
	void Release_GameObject_Manager(); 
private:
	list<CGameObject*> m_listGameObject[END];
};

