#pragma once
#include "GameObject.h"
class CTerrain final : public CGameObject
{
public:
	CTerrain();
	~CTerrain();
public:
	const vector<TILE*>& Get_VecTile() { return m_vecTile; }
public:
	HRESULT Create_Graph_Terrain();
	HRESULT LoadTileData_Terrain(const wstring& wstrFilePath); 
public:
	// CGameObject��(��) ���� ��ӵ�
	virtual HRESULT Ready_GameObject() override;
	virtual int Update_GameObject() override;
	virtual void Late_Update_GameObject() override;
	virtual void Render_GameObject() override;
	virtual void Release_GameObject() override;
private:
	vector<TILE*> m_vecTile; 
	vector<MAPOBJECT*>m_vecMap;
	vector<list<TILE*>> m_vecGraph; 


};

