#include "stdafx.h"
#include "Stage.h"
#include "GameObject_Manager.h"
#include "Terrain.h"
#include "Player.h"

CStage::CStage()
	:m_pGameObject_Manager(CGameObject_Manager::Get_Instance())
{
}


CStage::~CStage()
{
	Release_Scene();
}

HRESULT CStage::Ready_Scene()
{
	CGameObject* pObject = new CTerrain; 
	if (FAILED(pObject->Ready_GameObject()))
		return E_FAIL; 
	
	m_pGameObject_Manager->Add_GameObject_Manager(CGameObject_Manager::TERRAIN, pObject); 
	pObject = new CPlayer; 
	if (FAILED(pObject->Ready_GameObject()))
		return E_FAIL; 
	m_pGameObject_Manager->Add_GameObject_Manager(CGameObject_Manager::PLAYER, pObject); 
	return S_OK;
}

void CStage::Update_Scene()
{
	m_pGameObject_Manager->Update_GameObject_Manager();
}

void CStage::Render_Scene()
{
	m_pGameObject_Manager->Render_GameObject_Manager();
}

void CStage::Release_Scene()
{
	m_pGameObject_Manager->Destroy_Instance(); 
}
