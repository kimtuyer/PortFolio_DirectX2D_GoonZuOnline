#include "stdafx.h"
#include "MainApp.h"
#include "Scene_Manager.h"
#include "GameObject_Manager.h"
#include "Frame_Manager.h"
CMainApp::CMainApp()
	:m_pGraphic_Device(CGraphic_Device::Get_Instance())
	, m_pScene_Manager(CScene_Manager::Get_Instance())
{
}


CMainApp::~CMainApp()
{
	Release_MainApp(); 
}

HRESULT CMainApp::Ready_MainApp()
{
	CTime_Manager::Get_Instance()->Ready_Time_Manager(); 
	if (FAILED(m_pGraphic_Device->Ready_Graphic_Device(CGraphic_Device::MODE_WIN)))
		return E_FAIL; 
	//TileTexture
	if (FAILED(CTexture_Manager::Get_Instance()->Insert_Texture_Manager(CTexture_Manager::TEX_MULTI,
		L"../Texture/Stage/Terrain/Tile/Tile%d.png", L"Terrain",rgb, L"Tile", 36)))
		return E_FAIL;

	if (FAILED(CTexture_Manager::Get_Instance()->Insert_Texture_Manager(CTexture_Manager::TEX_MULTI,
		L"../Texture/Stage/Object/gate_%d.bmp", L"MapObject", rgb, L"Gate", 23)))
		return E_FAIL;


	if (FAILED(CTexture_Manager::Get_Instance()->Insert_Texture_Manager(CTexture_Manager::TEX_SINGLE,
		L"../Texture/Stage/Tile/Town.png", L"StartMap", rgb,L"Map", 1)))
		return E_FAIL;

	//Player-Attack Texture 
	if (FAILED(CTexture_Manager::Get_Instance()->Insert_Texture_Manager(CTexture_Manager::TEX_MULTI,
		L"../Texture/Stage/Player/Attack/AKIHA_AKI01_00%d.png", L"Player", rgb, L"Attack", 6)))
		return E_FAIL;

	m_pScene_Manager->Change_Scene_Manager(CScene_Manager::STAGE); 
	return S_OK;
}

void CMainApp::Update_MainApp()
{
	CTime_Manager::Get_Instance()->Update_Time_Manager(); 
	m_pScene_Manager->Update_Scene_Manager(); 
}

void CMainApp::Render_MainApp(CFrame_Manager* pFrame_Manager)
{
	m_pGraphic_Device->Render_Begin(); 

	const TEXINFO* pTexInfo2 = CTexture_Manager::Get_Instance()->Get_TexInfo_Manager(L"StartMap", L"Map");
	if (nullptr == pTexInfo2)
		return;
	D3DXMATRIX matScale, matTrans, matWorld;
	D3DXMatrixScaling(&matScale, 0.3f, 0.3f, 0.f);

	D3DXMatrixTranslation(&matTrans, 0+CScroll_Manager::Get_Instance()->Get_Scroll(CScroll_Manager::eSB_HORZ), CScroll_Manager::Get_Instance()->Get_Scroll(CScroll_Manager::eSB_VERT), 0.f);
	matWorld = matScale * matTrans;

	CGraphic_Device::Get_Instance()->Get_Sprite()->SetTransform(&matWorld);
	m_pGraphic_Device->Get_Sprite()->Draw(pTexInfo2->pTexture, nullptr, nullptr, nullptr, D3DCOLOR_ARGB(255, 255, 255, 255));

	m_pScene_Manager->Render_Scene_Manager(); 
	pFrame_Manager->Render_Frame_Manager(); 
	m_pGraphic_Device->Render_End(); 
}

void CMainApp::Release_MainApp()
{
	CTime_Manager::Destroy_Instance(); 
	CScroll_Manager::Destroy_Instance(); 
	CGameObject_Manager::Destroy_Instance(); 
	m_pScene_Manager->Destroy_Instance(); 
	m_pGraphic_Device->Destroy_Instance(); 
	
}
