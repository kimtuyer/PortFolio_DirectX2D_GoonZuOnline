#include "stdafx.h"
#include "Player.h"


CPlayer::CPlayer()
//	:m_tInfo({})
	: m_tFrame({})
{
	ZeroMemory(&m_tInfo, sizeof(INFO));

}


CPlayer::~CPlayer()
{
	Release_GameObject(); 
}

void CPlayer::FrameMove(float fSpeed)
{
	m_tFrame.fFrameStart += m_tFrame.fFrameEnd * CTime_Manager::Get_Instance()->Get_DeltaTime() * fSpeed; 
	if (m_tFrame.fFrameEnd < m_tFrame.fFrameStart)
		m_tFrame.fFrameStart = 0.f; 
}



HRESULT CPlayer::Ready_GameObject()
{
	m_tInfo.vPos = { 400.f, 300.f, 0.f }; 
	m_tInfo.vDir = { 1.f, 1.f, 0.f }; 
	m_tInfo.vSize = { 1.f, 1.f, 0.f }; 
	m_tFrame = { 0.f, 6.f }; 
	return S_OK;
}
int CPlayer::Update_GameObject()
{
	return OBJ_NOEVENT; 
}
void CPlayer::Late_Update_GameObject()
{
	FrameMove(0.5f); 
}

void CPlayer::Render_GameObject()
{
	const TEXINFO* pTexInfo = CTexture_Manager::Get_Instance()->Get_TexInfo_Manager(L"Player", L"Attack", (DWORD)m_tFrame.fFrameStart); 
	if (nullptr == pTexInfo)
		return; 
	D3DXMATRIX matScale, matTrans, matWorld; 
	D3DXMatrixScaling(&matScale, m_tInfo.vSize.x, m_tInfo.vSize.y, 0.f); 
	D3DXMatrixTranslation(&matTrans, m_tInfo.vPos.x, m_tInfo.vPos.y, 0.f); 
	matWorld = matScale * matTrans; 
	float fCenterX = pTexInfo->tImageInfo.Width >> 1; 
	float fCenterY = pTexInfo->tImageInfo.Height >> 1; 

	CGraphic_Device::Get_Instance()->Get_Sprite()->SetTransform(&matWorld); 
	CGraphic_Device::Get_Instance()->Get_Sprite()->Draw(pTexInfo->pTexture, nullptr, &D3DXVECTOR3(fCenterX, fCenterY, 0.f), nullptr, D3DCOLOR_ARGB(255, 255, 255, 255)); 
}

void CPlayer::Release_GameObject()
{
}
